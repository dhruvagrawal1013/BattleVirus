var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["f319276d-da99-4936-900e-4599264dc0b4","f35a0215-10dc-4aa2-beab-4de88acc4ab8","7234cae0-9e71-466d-961a-3b7f84ade3a4","a026ef75-9b9d-449d-b045-d1eaec5909cb","5ddfbe46-90bb-4624-bd0a-ac6268fb5817","8f3aa501-fa18-43b7-bbc3-0a703f2e3f4b"],"propsByKey":{"f319276d-da99-4936-900e-4599264dc0b4":{"name":"enemy4","sourceUrl":null,"frameSize":{"x":390,"y":390},"frameCount":1,"looping":true,"frameDelay":12,"version":"GzlJmSKFF9EIFXY.scJXpfLVm67Vh3n.","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":390},"rootRelativePath":"assets/f319276d-da99-4936-900e-4599264dc0b4.png"},"f35a0215-10dc-4aa2-beab-4de88acc4ab8":{"name":"enemy3","sourceUrl":null,"frameSize":{"x":390,"y":390},"frameCount":1,"looping":true,"frameDelay":12,"version":"i46XPO.czdy9Xnal_3q31yCqLpn0ZIsV","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":390},"rootRelativePath":"assets/f35a0215-10dc-4aa2-beab-4de88acc4ab8.png"},"7234cae0-9e71-466d-961a-3b7f84ade3a4":{"name":"enemy2","sourceUrl":null,"frameSize":{"x":390,"y":390},"frameCount":1,"looping":true,"frameDelay":12,"version":"ZsNb8nq7YVKtPxF4fp2tfkdTIkLeaGsd","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":390},"rootRelativePath":"assets/7234cae0-9e71-466d-961a-3b7f84ade3a4.png"},"a026ef75-9b9d-449d-b045-d1eaec5909cb":{"name":"enemy1","sourceUrl":null,"frameSize":{"x":390,"y":390},"frameCount":1,"looping":true,"frameDelay":12,"version":"885g5ISaCwsxkthRSsJMLpRUchorDIJ7","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":390},"rootRelativePath":"assets/a026ef75-9b9d-449d-b045-d1eaec5909cb.png"},"5ddfbe46-90bb-4624-bd0a-ac6268fb5817":{"name":"hero","sourceUrl":null,"frameSize":{"x":116,"y":386},"frameCount":1,"looping":true,"frameDelay":12,"version":"..I7dth3Cbxin4v_0Kpw0aKsgr5FUflm","categories":["people"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":116,"y":386},"rootRelativePath":"assets/5ddfbe46-90bb-4624-bd0a-ac6268fb5817.png"},"8f3aa501-fa18-43b7-bbc3-0a703f2e3f4b":{"name":"hospital","sourceUrl":null,"frameSize":{"x":270,"y":206},"frameCount":1,"looping":true,"frameDelay":12,"version":"CGt0ptYdnw2k48dUDcZAj3Oaq36eGEcV","categories":["buildings"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":270,"y":206},"rootRelativePath":"assets/8f3aa501-fa18-43b7-bbc3-0a703f2e3f4b.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


 
var hero = createSprite(200,345,200,345);
hero.shapeColor="red";

var enemy1 = createSprite(200,250,10,10);
enemy1.shapeColor="red";

var enemy2 = createSprite(200,150,10,10);
enemy2.shapeColor="red";

var enemy3 = createSprite(200,50,10,10);
enemy3.shapeColor="red";

var hospital=createSprite(200,5,50,30);
hospital.setAnimation("hospital");
hospital.scale=0.2;

var goal =0;
var death = 0;

hero.setAnimation("hero");
hero.scale=0.2;
enemy1.setAnimation("enemy1");
enemy1.scale=0.1;
enemy2.setAnimation("enemy2");
enemy2.scale=0.1;
enemy3.setAnimation("enemy4");
enemy3.scale=0.1;




function draw() {
  
background("lavender");

createEdgeSprites();




enemy1.bounceOff(edges);
enemy2.bounceOff(edges);
enemy3.bounceOff(edges);

if(keyDown(ENTER)){
 enemy1.setVelocity(-10,3);
enemy2.setVelocity(10,-5);
enemy3.setVelocity(-10,7);

  
}




if(keyDown(UP_ARROW)){
  hero.y=hero.y-3;
}

if(keyDown(DOWN_ARROW)){
  hero.y=hero.y+3;
}

if(keyDown(LEFT_ARROW)){
  hero.x=hero.x-3;
}

if(keyDown(RIGHT_ARROW)){
  hero.x=hero.x+3
}

if(hero.isTouching(enemy1)|| hero.isTouching(enemy2)|| hero.isTouching(enemy3)){
  playSound("assets/category_achievements/bubbly_game_achievement_sound.mp3")
  hero.x=200
  hero.y=350
  death = death+1
}
if(hero.isTouching(hospital)){
  playSound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3")
  hero.x=200
  hero.y=345
  goal=goal+1
}
textSize(20)
  fill("blue")
  text("Goals:"+goal,320,350);
  

textSize(20)
  fill("blue")
  text("death:"+death,20,350);
  
drawSprites()
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
